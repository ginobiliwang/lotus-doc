#!/bin/bash
URLNUM=$#
if [ $URLNUM == 0 ];then
    echo "Please specify 1 url at least" >&2
    exit 1
fi
URLARY=()
while [ $# -gt 0 ]; do
    URLARY[${#URLARY[@]}]=$1
    shift
done
index=0
while [ $index -lt $URLNUM ];do
    rand1=$((RANDOM%URLNUM))
    rand2=$((RANDOM%URLNUM))
    if [ $rand1 != $rand2 ];then
        tmpurl=${URLARY[$rand1]}
        URLARY[$rand1]=${URLARY[$rand2]}
        URLARY[$rand2]=$tmpurl
    fi
    index=$((index+1))
done
if [ "$GP_SEGMENT_ID" == "-1" ];then
    GP_SEGMENT_ID=0
fi
HEADER="-H 'X-GP-XID: $GP_XID' -H 'X-GP-CID: $GP_CID' -H 'X-GP-SN: $GP_SN' -H 'X-GP-SEGMENT-ID: $GP_SEGMENT_ID' -H 'X-GP-SEGMENT-COUNT: $GP_SEGMENT_COUNT'"
HEADER="$HEADER -H 'X-GP-PROTO: 0' -H 'X-GP-MASTER_HOST: $GP_MASTER_HOST' -H 'X-GP-MASTER_PORT: $GP_MASTER_PORT' -H 'X-GP-DATABASE: $GP_DATABASE'"
HEADER="$HEADER -H 'X-GP-USER: $GP_USER' -H 'X-GP-SEG-PORT: $GP_SEG_PORT' -H 'X-GP-SESSION-ID: $GP_SESSION_ID' -H 'X-GP-ZSTD: 1'"
set -o pipefail
for CURLURL in ${URLARY[@]};do
    echo curl --silent $HEADER $CURLURL|bash|unzstd
done
